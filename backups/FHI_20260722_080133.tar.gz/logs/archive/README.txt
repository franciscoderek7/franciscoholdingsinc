Log archive created
