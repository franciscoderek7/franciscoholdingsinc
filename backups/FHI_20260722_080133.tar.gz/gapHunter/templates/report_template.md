Gap Hunter Report Template
